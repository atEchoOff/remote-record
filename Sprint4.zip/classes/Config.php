<?php

// class Config
// {
//     public static $db = [
//         "host" => "localhost",
//         "user" => "root",
//         "pass" => "",
//         "database" => "composer"
//     ];
// }

//The following are the config settings for getting it to run on the server
class Config {
    public static $db = [
        "host" => "localhost",
        "user" => "jjc9bb",
        "pass" => "6GYME5ZUQQ8l",
        "database" => "jjc9bb"
    ];
}

