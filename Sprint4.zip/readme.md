Upcoming tasks/fixes:
composition name is unique (bad)
	also change name to id in join db
	rename id to name in database setup lol (last resort)
regex server-side email validation
JSON
protect setup.php
delete audio file when deleting froem database (peinis)
make composition id file names

play/pause icon when toggling play

deleting/leaving compositions (composer?)
directory traversal should not be allowed lol

Being fixed now:
JSON
regex server-side email validation

Questions to ask:
Store files in dir?
Can we use javascript libraries
Can we use a python script?